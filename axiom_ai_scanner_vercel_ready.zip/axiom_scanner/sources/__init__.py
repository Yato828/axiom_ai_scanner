"""Market data source adapters."""

